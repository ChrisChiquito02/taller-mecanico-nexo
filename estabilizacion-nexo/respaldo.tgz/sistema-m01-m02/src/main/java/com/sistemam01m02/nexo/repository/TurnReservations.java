package com.sistemam01m02.nexo.repository;

import com.sistemam01m02.shared.error.ApiException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class TurnReservations {
  private static final String OWNER = "owner_id=UNHEX(REPLACE(?,'-',''))";
  private static final String ACTIVE = "expires_at>UTC_TIMESTAMP(6)";
  private final JdbcTemplate db;

  public TurnReservations(JdbcTemplate db) {
    this.db = db;
  }

  public void acquire(String owner, String chat, String turn, int lifetimeSeconds) {
    db.update("DELETE FROM nexo_turn_reservation WHERE " + OWNER + " AND NOT (" + ACTIVE + ")", owner);
    try {
      db.update("""
          INSERT INTO nexo_turn_reservation(owner_id,conversation_id,turn_id,expires_at)
          VALUES(UNHEX(REPLACE(?,'-','')),?,?,TIMESTAMPADD(SECOND,?,UTC_TIMESTAMP(6)))
          """, owner, chat, turn, lifetimeSeconds);
    } catch (DuplicateKeyException e) {
      throw new ApiException(409, "BUSY", "Ya tienes una respuesta en curso");
    }
  }

  public boolean running(String owner, String chat) {
    return !db.queryForList("SELECT 1 FROM nexo_turn_reservation WHERE " + OWNER
        + " AND conversation_id=? AND " + ACTIVE + " AND NOT cancelled", owner, chat).isEmpty();
  }

  public boolean cancel(String owner, String chat, String turn) {
    return db.update("UPDATE nexo_turn_reservation SET cancelled=TRUE WHERE " + OWNER
        + " AND conversation_id=? AND turn_id=? AND " + ACTIVE, owner, chat, turn) == 1;
  }

  public boolean active(String owner, String turn, boolean lock) {
    return !db.queryForList("SELECT 1 FROM nexo_turn_reservation WHERE " + OWNER
        + " AND turn_id=? AND " + ACTIVE + " AND NOT cancelled" + (lock ? " FOR UPDATE" : ""),
        owner, turn).isEmpty();
  }

  public void release(String owner, String turn) {
    db.update("DELETE FROM nexo_turn_reservation WHERE " + OWNER + " AND turn_id=?", owner, turn);
  }

  public void purge() {
    db.update("DELETE FROM nexo_turn_reservation WHERE NOT (" + ACTIVE + ")");
  }
}
