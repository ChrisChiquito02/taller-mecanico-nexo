package com.sistemam01m02.nexo.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OutputConstraintsTest {
  @Test void detectsDisjointBoundsForTheSameOutput() {
    assertTrue(OutputConstraints.clarification("Escribe exactamente tres líneas y al menos cinco líneas.").isPresent());
    assertTrue(OutputConstraints.clarification("Devuelve al menos 9 palabras y como máximo 4 palabras").isPresent());
    assertTrue(OutputConstraints.clarification("Write at least 8 paragraphs and at most 2 paragraphs.").orElseThrow().contains("Which"));
  }

  @Test void leavesAlternativesQuotesAndCompatibleConstraintsToTheModel() {
    for (String text : new String[] {
        "Escribe exactamente tres líneas y al menos dos líneas.",
        "Escribe exactamente tres líneas y exactamente cuatro palabras.",
        "Escribe exactamente tres líneas o al menos cinco líneas.",
        "Analiza la frase: «Escribe exactamente tres líneas y al menos cinco líneas.»",
        "Escribe exactamente tres líneas y exactamente cinco líneas para otra sección."}) {
      assertTrue(OutputConstraints.clarification(text).isEmpty(), text);
    }
  }
}
