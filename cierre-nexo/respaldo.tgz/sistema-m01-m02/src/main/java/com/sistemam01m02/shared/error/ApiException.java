package com.sistemam01m02.shared.error;

public class ApiException extends RuntimeException {
  private final int status;
  private final String code;

  public ApiException(int status, String code, String message) {
    super(message);
    this.status = status;
    this.code = code;
  }

  public int status() {
    return status;
  }

  public String code() {
    return code;
  }

  public static ApiException unauthorized() {
    return new ApiException(401, "INVALID_CREDENTIALS", "Credenciales o sesión inválidas");
  }
}
