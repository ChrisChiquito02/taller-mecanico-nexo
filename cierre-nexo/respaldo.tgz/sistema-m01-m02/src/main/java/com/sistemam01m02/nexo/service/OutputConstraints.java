package com.sistemam01m02.nexo.service;

import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

/** Checks an explicit conjunction about the size of a single output. */
final class OutputConstraints {
  private static final String BOUND = "(exactamente|al menos|como minimo|como maximo|a lo sumo|hasta|exactly|at least|at most)";
  private static final String COUNT = "([0-9]{1,9}|cero|una?|uno|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|zero|one|two|three|four|five|six|seven|eight|nine|ten)";
  private static final String UNIT = "(palabras?|lineas?|frases?|parrafos?|words?|lines?|sentences?|paragraphs?)";
  private static final String LIMIT = BOUND + "\\s+" + COUNT + "\\s+" + UNIT + "\\b";
  private static final Pattern PAIR = Pattern.compile("^(?:responde|escribe|redacta|devuelve|genera|usa|answer|write|return|use)"
      + "\\s+(?:(?:con|en|with|in)\\s+)?" + LIMIT
      + "\\s+(?:y|and)\\s+(?:(?:con|en|with|in)\\s+)?" + LIMIT + "(?=\\s*(?:[.!?¿]|$))");
  private static final Map<String,Integer> NUMBERS = Map.ofEntries(
      Map.entry("cero",0), Map.entry("una",1), Map.entry("un",1), Map.entry("uno",1),
      Map.entry("dos",2), Map.entry("tres",3), Map.entry("cuatro",4), Map.entry("cinco",5),
      Map.entry("seis",6), Map.entry("siete",7), Map.entry("ocho",8), Map.entry("nueve",9), Map.entry("diez",10),
      Map.entry("zero",0), Map.entry("one",1), Map.entry("two",2), Map.entry("three",3),
      Map.entry("four",4), Map.entry("five",5), Map.entry("six",6), Map.entry("seven",7),
      Map.entry("eight",8), Map.entry("nine",9), Map.entry("ten",10));
  private record Range(int min, int max) {}

  private OutputConstraints() {}

  static Optional<String> clarification(String prompt) {
    var match = PAIR.matcher(KnowledgeBase.normalize(prompt));
    if (!match.find() || !singular(match.group(3)).equals(singular(match.group(6)))) return Optional.empty();
    Range first = range(match.group(1), match.group(2));
    Range second = range(match.group(4), match.group(5));
    if (Math.max(first.min(), second.min()) <= Math.min(first.max(), second.max())) return Optional.empty();
    String left = match.group(1) + " " + match.group(2) + " " + match.group(3);
    String right = match.group(4) + " " + match.group(5) + " " + match.group(6);
    boolean english = match.group(1).matches("exactly|at least|at most");
    return Optional.of(english
        ? "The requirements “" + left + "” and “" + right + "” conflict. Which should I follow?"
        : "Las restricciones «" + left + "» y «" + right + "» son incompatibles. ¿Cuál debo seguir?");
  }

  private static String singular(String unit) {
    return unit.endsWith("s") ? unit.substring(0, unit.length() - 1) : unit;
  }

  private static Range range(String bound, String count) {
    int n = Character.isDigit(count.charAt(0)) ? Integer.parseInt(count) : NUMBERS.get(count);
    return switch (bound) {
      case "al menos", "como minimo", "at least" -> new Range(n, Integer.MAX_VALUE);
      case "como maximo", "a lo sumo", "hasta", "at most" -> new Range(0, n);
      default -> new Range(n, n);
    };
  }
}
